/**
 * script.js — Student Skill & Placement Management System
 * Simple utility JS: auto-dismiss alerts, delete confirmations
 */

// ─────────────────────────────────────────────
// Auto-dismiss flash alerts after 4 seconds
// ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function () {
    const alerts = document.querySelectorAll('.flash-alert');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            // Use Bootstrap's alert hide method if available
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            bsAlert.close();
        }, 4000);
    });
});

// ─────────────────────────────────────────────
// Confirm dialog before delete actions
// ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function () {
    const deleteForms = document.querySelectorAll('.delete-form');
    deleteForms.forEach(function (form) {
        form.addEventListener('submit', function (event) {
            const confirmed = window.confirm(
                'Are you sure you want to delete this item? This action cannot be undone.'
            );
            if (!confirmed) {
                event.preventDefault();  // Cancel form submission if user clicks Cancel
            }
        });
    });
});

// ─────────────────────────────────────────────
// Highlight active nav link based on URL
// ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function () {
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    const currentPath = window.location.pathname;

    navLinks.forEach(function (link) {
        const href = link.getAttribute('href');
        if (href && currentPath.startsWith(href) && href !== '/') {
            link.classList.add('active');
        }
    });
});
