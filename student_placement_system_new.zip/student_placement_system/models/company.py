# models/company.py
# Company model — represents a recruiting company in the placement system

from extensions import db


class Company(db.Model):
    """Represents a company that posts job listings."""
    __tablename__ = 'companies'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    industry = db.Column(db.String(100))
    location = db.Column(db.String(100))
    email = db.Column(db.String(100))
    website = db.Column(db.String(200))

    # One company can have many jobs
    jobs = db.relationship('Job', backref='company', lazy=True)

    def __repr__(self):
        return f'<Company {self.name}>'
