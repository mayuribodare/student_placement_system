# models/job.py
# Job model — represents a job posting by a company

from extensions import db


class Job(db.Model):
    """Represents a job opening posted by a company."""
    __tablename__ = 'jobs'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False)
    required_skills = db.Column(db.Text)          # Comma-separated skills
    min_cgpa = db.Column(db.Float)                # Minimum CGPA requirement
    eligible_year = db.Column(db.Integer)         # Which year students can apply (e.g. 4)
    location = db.Column(db.String(100))
    description = db.Column(db.Text)
    deadline = db.Column(db.Date)                 # Application deadline
    is_active = db.Column(db.Boolean, default=True)

    # One job can have many applications
    applications = db.relationship('Application', backref='job', lazy=True)

    def __repr__(self):
        return f'<Job {self.title}>'
