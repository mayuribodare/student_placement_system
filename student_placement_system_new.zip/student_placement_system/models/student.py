# models/student.py
# StudentProfile model — stores detailed academic and personal info for each student

from extensions import db


class StudentProfile(db.Model):
    """Stores detailed profile information for a student user."""
    __tablename__ = 'student_profiles'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    roll_number = db.Column(db.String(20))
    name = db.Column(db.String(100))
    phone = db.Column(db.String(15))
    department = db.Column(db.String(50))
    year = db.Column(db.Integer)
    cgpa = db.Column(db.Float)
    gender = db.Column(db.String(10))
    address = db.Column(db.Text)
    career_interest = db.Column(db.String(200))
    resume_link = db.Column(db.String(300))

    # One student has many skills and many applications
    skills = db.relationship('Skill', backref='student', lazy=True)
    applications = db.relationship('Application', backref='student', lazy=True)

    def __repr__(self):
        return f'<StudentProfile {self.name} ({self.roll_number})>'
