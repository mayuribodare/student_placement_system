# models/skill.py
# Skill model — each student can have multiple skills with category and proficiency level

from extensions import db


class Skill(db.Model):
    """Represents a single skill belonging to a student."""
    __tablename__ = 'skills'

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student_profiles.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    # Category: Programming, Database, Web Dev, Networking, Cloud, Soft Skills
    category = db.Column(db.String(50))
    # Proficiency: Beginner, Intermediate, Advanced
    proficiency = db.Column(db.String(20))

    def __repr__(self):
        return f'<Skill {self.name} ({self.proficiency})>'
