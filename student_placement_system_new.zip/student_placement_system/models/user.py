# models/user.py
# User model for authentication (admin and student roles)

from extensions import db
from werkzeug.security import generate_password_hash, check_password_hash


class User(db.Model):
    """Represents a system user (admin or student)."""
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(10), default='student')  # 'admin' or 'student'
    created_at = db.Column(db.DateTime, default=db.func.now())

    # One-to-one relationship to student profile
    profile = db.relationship('StudentProfile', backref='user', uselist=False)

    def set_password(self, password):
        """Hash and store the password."""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        """Check if provided password matches stored hash."""
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f'<User {self.username} ({self.role})>'
