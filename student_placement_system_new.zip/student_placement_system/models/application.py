# models/application.py
# Application model — tracks a student's application to a job

from extensions import db


class Application(db.Model):
    """Represents a student's application for a specific job."""
    __tablename__ = 'applications'

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student_profiles.id'), nullable=False)
    job_id = db.Column(db.Integer, db.ForeignKey('jobs.id'), nullable=False)
    # Status: Applied, Shortlisted, Selected, Rejected
    status = db.Column(db.String(20), default='Applied')
    applied_at = db.Column(db.DateTime, default=db.func.now())
    notes = db.Column(db.Text)   # Admin notes about the application

    def __repr__(self):
        return f'<Application Student:{self.student_id} Job:{self.job_id} Status:{self.status}>'
