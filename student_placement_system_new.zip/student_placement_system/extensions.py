# extensions.py
# Shared Flask extensions — imported by app.py AND models to avoid circular imports

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
