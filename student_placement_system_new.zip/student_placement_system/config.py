import os

basedir = os.path.abspath(os.path.dirname(__file__))

class Config:
    """Application configuration class."""
    SECRET_KEY = 'placement_secret_2024'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(basedir, 'database', 'placement.db').replace('\\', '/')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    DEBUG = True
