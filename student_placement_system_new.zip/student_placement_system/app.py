# app.py
# Main application entry point for the Student Skill and Placement Management System
# B.Tech Project — Flask + SQLAlchemy + SQLite

import os
from flask import Flask
from extensions import db

# ── Ensure the database directory exists before SQLite tries to use it ──
os.makedirs('database', exist_ok=True)

# ── Create Flask app and load configuration ──
app = Flask(__name__)
app.config.from_object('config.Config')

# ── Bind SQLAlchemy to this app ──
db.init_app(app)

# ── Import models AFTER db is created (avoids circular imports) ──
from models.user import User
from models.student import StudentProfile
from models.skill import Skill
from models.company import Company
from models.job import Job
from models.application import Application

# ── Import and register all Blueprints ──
from routes.auth_routes import auth_bp
from routes.student_routes import student_bp
from routes.skill_routes import skill_bp
from routes.company_routes import company_bp
from routes.job_routes import job_bp
from routes.application_routes import application_bp
from routes.dashboard_routes import dashboard_bp
from routes.report_routes import report_bp

app.register_blueprint(auth_bp)
app.register_blueprint(student_bp)
app.register_blueprint(skill_bp)
app.register_blueprint(company_bp)
app.register_blueprint(job_bp)
app.register_blueprint(application_bp)
app.register_blueprint(dashboard_bp)
app.register_blueprint(report_bp)


# ══════════════════════════════════════════════════════
# SEED DATA — Populates the DB with sample records
# Only runs if no users exist (safe to call on startup)
# ══════════════════════════════════════════════════════
def seed_data():
    """Insert sample data into the database if it is empty."""
    if User.query.first():
        return  # DB already has data; skip seeding

    print("Seeding sample data...")

    # ── 1. Admin user ──
    admin = User(username='admin', email='admin@placement.com', role='admin')
    admin.set_password('admin123')
    db.session.add(admin)

    # ── 2. Student users with profiles ──
    students_data = [
        {
            'username': 'rahul_s', 'email': 'rahul@student.com',
            'name': 'Rahul Sharma', 'roll': 'IT2021001',
            'dept': 'Information Technology', 'year': 4,
            'cgpa': 8.5, 'gender': 'Male', 'phone': '9876543210',
            'career_interest': 'Software Development',
            'skills': [
                ('Python', 'Programming', 'Advanced'),
                ('MySQL', 'Database', 'Intermediate'),
                ('Flask', 'Web Dev', 'Intermediate'),
            ]
        },
        {
            'username': 'priya_m', 'email': 'priya@student.com',
            'name': 'Priya Mehta', 'roll': 'IT2021002',
            'dept': 'Information Technology', 'year': 4,
            'cgpa': 7.8, 'gender': 'Female', 'phone': '9876543211',
            'career_interest': 'Data Science',
            'skills': [
                ('Machine Learning', 'Programming', 'Intermediate'),
                ('Python', 'Programming', 'Advanced'),
                ('Tableau', 'Database', 'Beginner'),
            ]
        },
        {
            'username': 'arjun_k', 'email': 'arjun@student.com',
            'name': 'Arjun Kumar', 'roll': 'CS2021001',
            'dept': 'Computer Science', 'year': 4,
            'cgpa': 9.1, 'gender': 'Male', 'phone': '9876543212',
            'career_interest': 'Cloud Computing',
            'skills': [
                ('Java', 'Programming', 'Advanced'),
                ('AWS', 'Cloud', 'Intermediate'),
                ('Docker', 'Cloud', 'Intermediate'),
            ]
        },
        {
            'username': 'sneha_p', 'email': 'sneha@student.com',
            'name': 'Sneha Patel', 'roll': 'CS2021002',
            'dept': 'Computer Science', 'year': 3,
            'cgpa': 8.2, 'gender': 'Female', 'phone': '9876543213',
            'career_interest': 'Web Development',
            'skills': [
                ('React', 'Web Dev', 'Intermediate'),
                ('JavaScript', 'Programming', 'Advanced'),
                ('MongoDB', 'Database', 'Beginner'),
            ]
        },
        {
            'username': 'vikram_r', 'email': 'vikram@student.com',
            'name': 'Vikram Rao', 'roll': 'EC2021001',
            'dept': 'Electronics', 'year': 4,
            'cgpa': 7.5, 'gender': 'Male', 'phone': '9876543214',
            'career_interest': 'Embedded Systems',
            'skills': [
                ('C/C++', 'Programming', 'Advanced'),
                ('Networking', 'Networking', 'Intermediate'),
                ('Linux', 'Cloud', 'Beginner'),
            ]
        },
    ]

    profiles = {}  # store profile objects by username for later use
    for sdata in students_data:
        user = User(username=sdata['username'], email=sdata['email'], role='student')
        user.set_password('student123')
        db.session.add(user)
        db.session.flush()

        profile = StudentProfile(
            user_id=user.id,
            name=sdata['name'],
            roll_number=sdata['roll'],
            department=sdata['dept'],
            year=sdata['year'],
            cgpa=sdata['cgpa'],
            gender=sdata['gender'],
            phone=sdata['phone'],
            career_interest=sdata['career_interest']
        )
        db.session.add(profile)
        db.session.flush()

        # Add skills for this student
        for skill_name, skill_cat, skill_prof in sdata['skills']:
            skill = Skill(
                student_id=profile.id,
                name=skill_name,
                category=skill_cat,
                proficiency=skill_prof
            )
            db.session.add(skill)

        profiles[sdata['username']] = profile

    # ── 3. Companies ──
    companies_data = [
        Company(name='TechCorp Solutions', industry='Software', location='Bengaluru',
                email='hr@techcorp.com', website='https://techcorp.com'),
        Company(name='InfoSys Ltd', industry='IT Services', location='Hyderabad',
                email='hr@infosys-demo.com', website='https://infosys.com'),
        Company(name='DataWave Analytics', industry='Data Analytics', location='Pune',
                email='hr@datawave.com', website='https://datawave.com'),
        Company(name='CloudNine Technologies', industry='Cloud Services', location='Mumbai',
                email='hr@cloudnine.com', website='https://cloudnine.com'),
    ]
    for c in companies_data:
        db.session.add(c)
    db.session.flush()

    tc = Company.query.filter_by(name='TechCorp Solutions').first()
    isy = Company.query.filter_by(name='InfoSys Ltd').first()
    dw = Company.query.filter_by(name='DataWave Analytics').first()
    cn = Company.query.filter_by(name='CloudNine Technologies').first()

    # ── 4. Jobs ──
    from datetime import date
    jobs_data = [
        Job(title='Python Backend Developer', company_id=tc.id,
            required_skills='Python, Flask, MySQL', min_cgpa=7.5,
            eligible_year=4, location='Bengaluru',
            description='Develop and maintain backend services using Python and Flask.',
            deadline=date(2026, 12, 31), is_active=True),
        Job(title='Data Analyst', company_id=dw.id,
            required_skills='Python, Tableau, Excel', min_cgpa=7.0,
            eligible_year=4, location='Pune',
            description='Analyze large datasets and create insightful visualizations.',
            deadline=date(2026, 11, 30), is_active=True),
        Job(title='Cloud Engineer', company_id=cn.id,
            required_skills='AWS, Docker, Linux', min_cgpa=7.5,
            eligible_year=4, location='Mumbai',
            description='Design and manage cloud infrastructure on AWS.',
            deadline=date(2026, 12, 15), is_active=True),
        Job(title='Java Developer', company_id=isy.id,
            required_skills='Java, Spring Boot, MySQL', min_cgpa=7.0,
            eligible_year=4, location='Hyderabad',
            description='Build enterprise applications using Java and Spring Boot.',
            deadline=date(2026, 11, 15), is_active=True),
        Job(title='Frontend Developer', company_id=tc.id,
            required_skills='React, JavaScript, CSS', min_cgpa=6.5,
            eligible_year=3, location='Bengaluru',
            description='Create responsive UI with React and modern JavaScript.',
            deadline=date(2026, 12, 1), is_active=True),
        Job(title='Network Engineer', company_id=isy.id,
            required_skills='Networking, Linux, C/C++', min_cgpa=7.0,
            eligible_year=4, location='Hyderabad',
            description='Configure and maintain enterprise networking solutions.',
            deadline=date(2026, 10, 31), is_active=True),
    ]
    for j in jobs_data:
        db.session.add(j)
    db.session.flush()

    # Fetch jobs by title for applications
    def get_job(title):
        return Job.query.filter_by(title=title).first()

    # ── 5. Applications (8 total, mixed statuses) ──
    apps_data = [
        # Rahul applied for Python Backend Developer → Shortlisted
        (profiles['rahul_s'].id, get_job('Python Backend Developer').id, 'Shortlisted'),
        # Rahul applied for Data Analyst → Applied
        (profiles['rahul_s'].id, get_job('Data Analyst').id, 'Applied'),
        # Priya applied for Data Analyst → Selected
        (profiles['priya_m'].id, get_job('Data Analyst').id, 'Selected'),
        # Priya applied for Python Backend Developer → Rejected
        (profiles['priya_m'].id, get_job('Python Backend Developer').id, 'Rejected'),
        # Arjun applied for Cloud Engineer → Shortlisted
        (profiles['arjun_k'].id, get_job('Cloud Engineer').id, 'Shortlisted'),
        # Arjun applied for Java Developer → Selected
        (profiles['arjun_k'].id, get_job('Java Developer').id, 'Selected'),
        # Sneha applied for Frontend Developer → Applied
        (profiles['sneha_p'].id, get_job('Frontend Developer').id, 'Applied'),
        # Vikram applied for Network Engineer → Applied
        (profiles['vikram_r'].id, get_job('Network Engineer').id, 'Applied'),
    ]
    for student_id, job_id, status in apps_data:
        app_record = Application(student_id=student_id, job_id=job_id, status=status)
        db.session.add(app_record)

    db.session.commit()
    print("Sample data seeded successfully!")


# ══════════════════════════════════════════════════════
# ENTRY POINT
# ══════════════════════════════════════════════════════
if __name__ == '__main__':
    with app.app_context():
        db.create_all()   # Create all tables
        seed_data()       # Insert sample data (only if DB is empty)
    app.run(debug=True)
