# routes/skill_routes.py
# Skill management routes — students can add, edit, and delete their skills

from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from extensions import db
from models.user import User
from models.skill import Skill

skill_bp = Blueprint('skill', __name__, url_prefix='/skill')

SKILL_CATEGORIES = ['Programming', 'Database', 'Web Dev', 'Networking', 'Cloud', 'Soft Skills']
PROFICIENCY_LEVELS = ['Beginner', 'Intermediate', 'Advanced']


def student_required(f):
    """Decorator: require student role."""
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to continue.', 'warning')
            return redirect(url_for('auth.login'))
        if session.get('role') != 'student':
            flash('Access denied. Students only.', 'danger')
            return redirect(url_for('dashboard.home'))
        return f(*args, **kwargs)
    return decorated


def get_student_profile():
    """Helper: Return the StudentProfile for the currently logged-in student."""
    user = User.query.get(session['user_id'])
    return user.profile if user else None


# ─────────────────────────────────────────────
# LIST SKILLS
# ─────────────────────────────────────────────
@skill_bp.route('/')
@student_required
def list_skills():
    """List all skills of the logged-in student."""
    profile = get_student_profile()
    skills = profile.skills if profile else []
    return render_template('student/skills.html', skills=skills,
                           categories=SKILL_CATEGORIES,
                           proficiency_levels=PROFICIENCY_LEVELS)


# ─────────────────────────────────────────────
# ADD SKILL
# ─────────────────────────────────────────────
@skill_bp.route('/add', methods=['GET', 'POST'])
@student_required
def add_skill():
    """Add a new skill for the logged-in student."""
    profile = get_student_profile()

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        category = request.form.get('category', '').strip()
        proficiency = request.form.get('proficiency', '').strip()

        if not name:
            flash('Skill name is required.', 'warning')
            return redirect(url_for('skill.list_skills'))

        skill = Skill(
            student_id=profile.id,
            name=name,
            category=category,
            proficiency=proficiency
        )
        db.session.add(skill)
        db.session.commit()
        flash(f'Skill "{name}" added successfully!', 'success')
        return redirect(url_for('skill.list_skills'))

    return render_template('student/skills.html',
                           skills=profile.skills if profile else [],
                           categories=SKILL_CATEGORIES,
                           proficiency_levels=PROFICIENCY_LEVELS)


# ─────────────────────────────────────────────
# EDIT SKILL
# ─────────────────────────────────────────────
@skill_bp.route('/edit/<int:skill_id>', methods=['GET', 'POST'])
@student_required
def edit_skill(skill_id):
    """Edit an existing skill (only owner can edit)."""
    profile = get_student_profile()
    skill = Skill.query.get_or_404(skill_id)

    # Security: ensure the skill belongs to this student
    if skill.student_id != profile.id:
        flash('You are not authorized to edit this skill.', 'danger')
        return redirect(url_for('skill.list_skills'))

    if request.method == 'POST':
        skill.name = request.form.get('name', '').strip()
        skill.category = request.form.get('category', '').strip()
        skill.proficiency = request.form.get('proficiency', '').strip()
        db.session.commit()
        flash('Skill updated successfully!', 'success')
        return redirect(url_for('skill.list_skills'))

    return render_template('student/skills.html',
                           skills=profile.skills if profile else [],
                           edit_skill=skill,
                           categories=SKILL_CATEGORIES,
                           proficiency_levels=PROFICIENCY_LEVELS)


# ─────────────────────────────────────────────
# DELETE SKILL
# ─────────────────────────────────────────────
@skill_bp.route('/delete/<int:skill_id>', methods=['POST'])
@student_required
def delete_skill(skill_id):
    """Delete a skill (only owner can delete)."""
    profile = get_student_profile()
    skill = Skill.query.get_or_404(skill_id)

    if skill.student_id != profile.id:
        flash('You are not authorized to delete this skill.', 'danger')
        return redirect(url_for('skill.list_skills'))

    db.session.delete(skill)
    db.session.commit()
    flash('Skill deleted.', 'info')
    return redirect(url_for('skill.list_skills'))
