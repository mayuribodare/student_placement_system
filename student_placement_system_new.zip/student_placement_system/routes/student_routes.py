# routes/student_routes.py
# Student profile routes — view and edit student profile

from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from extensions import db
from models.user import User
from models.student import StudentProfile

student_bp = Blueprint('student', __name__, url_prefix='/student')


# ─────────────────────────────────────────────
# Helper decorators
# ─────────────────────────────────────────────
def login_required(f):
    """Decorator: require the user to be logged in."""
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to continue.', 'warning')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated


def student_required(f):
    """Decorator: require the user to have the 'student' role."""
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to continue.', 'warning')
            return redirect(url_for('auth.login'))
        if session.get('role') != 'student':
            flash('Access denied. Students only.', 'danger')
            return redirect(url_for('dashboard.home'))
        return f(*args, **kwargs)
    return decorated


# ─────────────────────────────────────────────
# VIEW PROFILE
# ─────────────────────────────────────────────
@student_bp.route('/profile')
@student_required
def profile():
    """Display the logged-in student's profile."""
    user = User.query.get(session['user_id'])
    profile = user.profile
    return render_template('student/profile.html', user=user, profile=profile)


# ─────────────────────────────────────────────
# EDIT PROFILE
# ─────────────────────────────────────────────
@student_bp.route('/profile/edit', methods=['GET', 'POST'])
@student_required
def edit_profile():
    """Allow students to update their profile details."""
    user = User.query.get(session['user_id'])
    profile = user.profile

    # If profile doesn't exist yet (edge case), create one
    if not profile:
        profile = StudentProfile(user_id=user.id)
        db.session.add(profile)
        db.session.commit()

    if request.method == 'POST':
        profile.name = request.form.get('name', '').strip()
        profile.roll_number = request.form.get('roll_number', '').strip()
        profile.phone = request.form.get('phone', '').strip()
        profile.department = request.form.get('department', '').strip()
        profile.gender = request.form.get('gender', '').strip()
        profile.address = request.form.get('address', '').strip()
        profile.career_interest = request.form.get('career_interest', '').strip()
        profile.resume_link = request.form.get('resume_link', '').strip()

        # Safely parse numeric fields
        try:
            profile.year = int(request.form.get('year', 0))
        except ValueError:
            profile.year = None

        try:
            profile.cgpa = float(request.form.get('cgpa', 0))
        except ValueError:
            profile.cgpa = None

        db.session.commit()
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('student.profile'))

    return render_template('student/profile.html', user=user, profile=profile, edit_mode=True)
