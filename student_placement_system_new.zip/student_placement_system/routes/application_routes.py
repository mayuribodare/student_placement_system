# routes/application_routes.py
# Application routes — students apply to jobs, admin manages status

from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from extensions import db
from models.application import Application
from models.job import Job
from models.user import User
from models.student import StudentProfile

application_bp = Blueprint('application', __name__, url_prefix='/application')


def student_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to continue.', 'warning')
            return redirect(url_for('auth.login'))
        if session.get('role') != 'student':
            flash('Students only.', 'danger')
            return redirect(url_for('dashboard.home'))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to continue.', 'warning')
            return redirect(url_for('auth.login'))
        if session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard.home'))
        return f(*args, **kwargs)
    return decorated


# ─────────────────────────────────────────────
# APPLY TO JOB
# ─────────────────────────────────────────────
@application_bp.route('/apply/<int:job_id>', methods=['POST'])
@student_required
def apply(job_id):
    """Student: Apply to a job (prevents duplicate applications)."""
    user = User.query.get(session['user_id'])
    profile = user.profile

    if not profile:
        flash('Please complete your profile before applying.', 'warning')
        return redirect(url_for('student.edit_profile'))

    job = Job.query.get_or_404(job_id)

    # Check for duplicate application
    existing = Application.query.filter_by(
        student_id=profile.id, job_id=job_id).first()
    if existing:
        flash('You have already applied for this job.', 'warning')
        return redirect(url_for('job.job_detail', job_id=job_id))

    application = Application(
        student_id=profile.id,
        job_id=job_id,
        status='Applied'
    )
    db.session.add(application)
    db.session.commit()
    flash(f'Successfully applied for "{job.title}"!', 'success')
    return redirect(url_for('application.my_applications'))


# ─────────────────────────────────────────────
# MY APPLICATIONS
# ─────────────────────────────────────────────
@application_bp.route('/my')
@student_required
def my_applications():
    """Student: View their own applications."""
    user = User.query.get(session['user_id'])
    profile = user.profile
    apps = profile.applications if profile else []
    return render_template('applications/my_applications.html', applications=apps)


# ─────────────────────────────────────────────
# MANAGE ALL APPLICATIONS (Admin)
# ─────────────────────────────────────────────
@application_bp.route('/manage')
@admin_required
def manage_applications():
    """Admin: View and manage all applications."""
    all_apps = Application.query.order_by(Application.applied_at.desc()).all()
    return render_template('admin/manage_applications.html', applications=all_apps)


# ─────────────────────────────────────────────
# UPDATE APPLICATION STATUS (Admin)
# ─────────────────────────────────────────────
@application_bp.route('/update_status/<int:app_id>', methods=['POST'])
@admin_required
def update_status(app_id):
    """Admin: Update the status of an application."""
    application = Application.query.get_or_404(app_id)
    new_status = request.form.get('status', 'Applied')

    allowed_statuses = ['Applied', 'Shortlisted', 'Selected', 'Rejected']
    if new_status not in allowed_statuses:
        flash('Invalid status value.', 'danger')
        return redirect(url_for('application.manage_applications'))

    application.status = new_status
    application.notes = request.form.get('notes', '').strip()
    db.session.commit()
    flash(f'Application status updated to "{new_status}".', 'success')
    return redirect(url_for('application.manage_applications'))
