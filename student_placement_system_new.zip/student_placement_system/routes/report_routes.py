# routes/report_routes.py
# Report routes — admin-only CSV exports and data preview tables

import csv
import io
from flask import Blueprint, render_template, session, redirect, url_for, flash, Response
from models.student import StudentProfile
from models.company import Company
from models.job import Job
from models.application import Application

report_bp = Blueprint('report', __name__, url_prefix='/report')


def admin_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to continue.', 'warning')
            return redirect(url_for('auth.login'))
        if session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard.home'))
        return f(*args, **kwargs)
    return decorated


# ─────────────────────────────────────────────
# REPORTS INDEX
# ─────────────────────────────────────────────
@report_bp.route('/')
@admin_required
def index():
    """Reports overview page with preview tables (first 10 rows each)."""
    students = StudentProfile.query.limit(10).all()
    companies = Company.query.limit(10).all()
    jobs = Job.query.limit(10).all()
    applications = Application.query.order_by(Application.applied_at.desc()).limit(10).all()

    return render_template('reports/index.html',
                           students=students,
                           companies=companies,
                           jobs=jobs,
                           applications=applications)


# ─────────────────────────────────────────────
# EXPORT: ALL STUDENTS CSV
# ─────────────────────────────────────────────
@report_bp.route('/export/students')
@admin_required
def export_students():
    """Download all student profiles as a CSV file."""
    students = StudentProfile.query.all()

    output = io.StringIO()
    writer = csv.writer(output)
    # Header row
    writer.writerow([
        'Roll Number', 'Name', 'Department', 'Year', 'CGPA',
        'Gender', 'Phone', 'Career Interest', 'Skills Count', 'Applications Count'
    ])
    for s in students:
        writer.writerow([
            s.roll_number or '',
            s.name or '',
            s.department or '',
            s.year or '',
            s.cgpa or '',
            s.gender or '',
            s.phone or '',
            s.career_interest or '',
            len(s.skills),
            len(s.applications)
        ])

    output.seek(0)
    return Response(
        output.getvalue(),
        mimetype='text/csv',
        headers={'Content-Disposition': 'attachment; filename=students_report.csv'}
    )


# ─────────────────────────────────────────────
# EXPORT: ALL APPLICATIONS CSV
# ─────────────────────────────────────────────
@report_bp.route('/export/applications')
@admin_required
def export_applications():
    """Download all applications as a CSV file."""
    applications = Application.query.order_by(Application.applied_at.desc()).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        'Application ID', 'Student Name', 'Roll Number', 'Department',
        'Job Title', 'Company', 'Status', 'Applied At', 'Notes'
    ])
    for app in applications:
        student = app.student
        job = app.job
        writer.writerow([
            app.id,
            student.name if student else '',
            student.roll_number if student else '',
            student.department if student else '',
            job.title if job else '',
            job.company.name if job and job.company else '',
            app.status,
            app.applied_at.strftime('%Y-%m-%d %H:%M') if app.applied_at else '',
            app.notes or ''
        ])

    output.seek(0)
    return Response(
        output.getvalue(),
        mimetype='text/csv',
        headers={'Content-Disposition': 'attachment; filename=applications_report.csv'}
    )


# ─────────────────────────────────────────────
# EXPORT: SELECTED STUDENTS CSV
# ─────────────────────────────────────────────
@report_bp.route('/export/selected')
@admin_required
def export_selected():
    """Download only 'Selected' applications as a CSV file."""
    selected = Application.query.filter_by(status='Selected').all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        'Student Name', 'Roll Number', 'Department', 'CGPA',
        'Job Title', 'Company', 'Location', 'Applied At'
    ])
    for app in selected:
        student = app.student
        job = app.job
        writer.writerow([
            student.name if student else '',
            student.roll_number if student else '',
            student.department if student else '',
            student.cgpa if student else '',
            job.title if job else '',
            job.company.name if job and job.company else '',
            job.location if job else '',
            app.applied_at.strftime('%Y-%m-%d') if app.applied_at else ''
        ])

    output.seek(0)
    return Response(
        output.getvalue(),
        mimetype='text/csv',
        headers={'Content-Disposition': 'attachment; filename=selected_students_report.csv'}
    )
