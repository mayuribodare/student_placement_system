# routes/job_routes.py
# Job listing routes — view (all), add/edit/delete (admin), search/filter support

from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from extensions import db
from models.job import Job
from models.company import Company
from models.application import Application
from models.user import User
from datetime import datetime

job_bp = Blueprint('job', __name__, url_prefix='/job')


def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to continue.', 'warning')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to continue.', 'warning')
            return redirect(url_for('auth.login'))
        if session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard.home'))
        return f(*args, **kwargs)
    return decorated


# ─────────────────────────────────────────────
# LIST JOBS (with search and filter)
# ─────────────────────────────────────────────
@job_bp.route('/')
@login_required
def list_jobs():
    """List all active jobs. Supports search by title and filter by company."""
    search = request.args.get('search', '').strip()
    company_filter = request.args.get('company_id', '')

    query = Job.query.filter_by(is_active=True)

    if search:
        query = query.filter(Job.title.ilike(f'%{search}%'))

    if company_filter:
        query = query.filter_by(company_id=int(company_filter))

    jobs = query.order_by(Job.id.desc()).all()
    companies = Company.query.order_by(Company.name).all()

    # Build set of job IDs the current student has already applied to
    applied_job_ids = set()
    if session.get('role') == 'student':
        user = User.query.get(session['user_id'])
        if user and user.profile:
            for app in user.profile.applications:
                applied_job_ids.add(app.job_id)

    return render_template('jobs/list.html', jobs=jobs, companies=companies,
                           search=search, company_filter=company_filter,
                           applied_job_ids=applied_job_ids)


# ─────────────────────────────────────────────
# JOB DETAIL
# ─────────────────────────────────────────────
@job_bp.route('/<int:job_id>')
@login_required
def job_detail(job_id):
    """Show full details for a single job."""
    job = Job.query.get_or_404(job_id)

    already_applied = False
    if session.get('role') == 'student':
        user = User.query.get(session['user_id'])
        if user and user.profile:
            existing = Application.query.filter_by(
                student_id=user.profile.id, job_id=job_id).first()
            already_applied = existing is not None

    return render_template('jobs/detail.html', job=job, already_applied=already_applied)


# ─────────────────────────────────────────────
# ADD JOB
# ─────────────────────────────────────────────
@job_bp.route('/add', methods=['GET', 'POST'])
@admin_required
def add_job():
    """Admin: Add a new job posting."""
    companies = Company.query.order_by(Company.name).all()

    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        company_id = request.form.get('company_id')

        if not title or not company_id:
            flash('Title and company are required.', 'warning')
            return render_template('jobs/form.html', job=None, companies=companies)

        deadline = None
        deadline_str = request.form.get('deadline', '').strip()
        if deadline_str:
            try:
                deadline = datetime.strptime(deadline_str, '%Y-%m-%d').date()
            except ValueError:
                flash('Invalid date format for deadline.', 'warning')
                return render_template('jobs/form.html', job=None, companies=companies)

        job = Job(
            title=title,
            company_id=int(company_id),
            required_skills=request.form.get('required_skills', '').strip(),
            location=request.form.get('location', '').strip(),
            description=request.form.get('description', '').strip(),
            deadline=deadline,
            is_active=True
        )

        try:
            job.min_cgpa = float(request.form.get('min_cgpa', 0))
        except ValueError:
            job.min_cgpa = 0.0

        try:
            job.eligible_year = int(request.form.get('eligible_year', 4))
        except ValueError:
            job.eligible_year = 4

        db.session.add(job)
        db.session.commit()
        flash(f'Job "{title}" added successfully!', 'success')
        return redirect(url_for('job.list_jobs'))

    return render_template('jobs/form.html', job=None, companies=companies)


# ─────────────────────────────────────────────
# EDIT JOB
# ─────────────────────────────────────────────
@job_bp.route('/edit/<int:job_id>', methods=['GET', 'POST'])
@admin_required
def edit_job(job_id):
    """Admin: Edit an existing job posting."""
    job = Job.query.get_or_404(job_id)
    companies = Company.query.order_by(Company.name).all()

    if request.method == 'POST':
        job.title = request.form.get('title', '').strip()
        job.company_id = int(request.form.get('company_id', job.company_id))
        job.required_skills = request.form.get('required_skills', '').strip()
        job.location = request.form.get('location', '').strip()
        job.description = request.form.get('description', '').strip()
        job.is_active = 'is_active' in request.form

        deadline_str = request.form.get('deadline', '').strip()
        if deadline_str:
            try:
                job.deadline = datetime.strptime(deadline_str, '%Y-%m-%d').date()
            except ValueError:
                flash('Invalid date format for deadline.', 'warning')
                return render_template('jobs/form.html', job=job, companies=companies)

        try:
            job.min_cgpa = float(request.form.get('min_cgpa', 0))
        except ValueError:
            pass

        try:
            job.eligible_year = int(request.form.get('eligible_year', 4))
        except ValueError:
            pass

        db.session.commit()
        flash('Job updated successfully!', 'success')
        return redirect(url_for('job.list_jobs'))

    return render_template('jobs/form.html', job=job, companies=companies)


# ─────────────────────────────────────────────
# DELETE JOB
# ─────────────────────────────────────────────
@job_bp.route('/delete/<int:job_id>', methods=['POST'])
@admin_required
def delete_job(job_id):
    """Admin: Delete a job posting."""
    job = Job.query.get_or_404(job_id)
    db.session.delete(job)
    db.session.commit()
    flash(f'Job "{job.title}" deleted.', 'info')
    return redirect(url_for('job.list_jobs'))
