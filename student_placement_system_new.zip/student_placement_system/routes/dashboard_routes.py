# routes/dashboard_routes.py
# Dashboard routes — landing home, admin dashboard with charts, student dashboard

import json
from flask import Blueprint, render_template, redirect, url_for, session
from extensions import db
from models.user import User
from models.student import StudentProfile
from models.company import Company
from models.job import Job
from models.application import Application

dashboard_bp = Blueprint('dashboard', __name__)


# ─────────────────────────────────────────────
# HOME / LANDING PAGE
# ─────────────────────────────────────────────
@dashboard_bp.route('/')
def home():
    """Root route: redirect logged-in users to their dashboard, else show home."""
    if 'user_id' in session:
        if session.get('role') == 'admin':
            return redirect(url_for('dashboard.admin_dashboard'))
        else:
            return redirect(url_for('dashboard.student_dashboard'))
    return render_template('home.html')


# ─────────────────────────────────────────────
# ADMIN DASHBOARD
# ─────────────────────────────────────────────
@dashboard_bp.route('/dashboard/admin')
def admin_dashboard():
    """Admin dashboard with summary statistics and Chart.js data."""
    if 'user_id' not in session or session.get('role') != 'admin':
        return redirect(url_for('auth.login'))

    # Summary counts
    total_students = StudentProfile.query.count()
    total_companies = Company.query.count()
    total_jobs = Job.query.count()
    total_applications = Application.query.count()
    total_selected = Application.query.filter_by(status='Selected').count()

    # ── Bar chart: Applications per job (top 5) ──
    top_jobs = (
        db.session.query(Job.title, db.func.count(Application.id).label('count'))
        .join(Application, Application.job_id == Job.id)
        .group_by(Job.id)
        .order_by(db.func.count(Application.id).desc())
        .limit(5)
        .all()
    )
    bar_labels = json.dumps([row.title for row in top_jobs])
    bar_data = json.dumps([row.count for row in top_jobs])

    # ── Doughnut chart: Application status distribution ──
    statuses = ['Applied', 'Shortlisted', 'Selected', 'Rejected']
    status_counts = []
    for s in statuses:
        count = Application.query.filter_by(status=s).count()
        status_counts.append(count)
    donut_labels = json.dumps(statuses)
    donut_data = json.dumps(status_counts)

    return render_template(
        'admin/dashboard.html',
        total_students=total_students,
        total_companies=total_companies,
        total_jobs=total_jobs,
        total_applications=total_applications,
        total_selected=total_selected,
        bar_labels=bar_labels,
        bar_data=bar_data,
        donut_labels=donut_labels,
        donut_data=donut_data
    )


# ─────────────────────────────────────────────
# STUDENT DASHBOARD
# ─────────────────────────────────────────────
@dashboard_bp.route('/dashboard/student')
def student_dashboard():
    """Student dashboard showing profile summary and quick links."""
    if 'user_id' not in session or session.get('role') != 'student':
        return redirect(url_for('auth.login'))

    user = User.query.get(session['user_id'])
    profile = user.profile if user else None

    skills_count = len(profile.skills) if profile else 0
    apps_count = len(profile.applications) if profile else 0
    active_jobs = Job.query.filter_by(is_active=True).count()

    return render_template(
        'student/dashboard.html',
        user=user,
        profile=profile,
        skills_count=skills_count,
        apps_count=apps_count,
        active_jobs=active_jobs
    )


# ─────────────────────────────────────────────
# ADMIN: ALL STUDENTS LIST
# ─────────────────────────────────────────────
@dashboard_bp.route('/admin/students')
def admin_students():
    """Admin: View all registered students with their stats."""
    if 'user_id' not in session or session.get('role') != 'admin':
        return redirect(url_for('auth.login'))

    students = StudentProfile.query.all()
    return render_template('admin/students.html', students=students)
