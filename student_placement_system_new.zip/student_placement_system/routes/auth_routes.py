# routes/auth_routes.py
# Authentication routes: login, register, logout

from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from extensions import db
from models.user import User
from models.student import StudentProfile

# Create the auth blueprint
auth_bp = Blueprint('auth', __name__, url_prefix='/auth')


# ─────────────────────────────────────────────
# LOGIN
# ─────────────────────────────────────────────
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Show login form (GET) or authenticate user (POST)."""
    # Redirect already-logged-in users
    if 'user_id' in session:
        return redirect(url_for('dashboard.home'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()

        if not username or not password:
            flash('Please enter both username and password.', 'warning')
            return render_template('login.html')

        user = User.query.filter_by(username=username).first()

        if user and user.check_password(password):
            # Store user info in session
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            flash(f'Welcome back, {user.username}!', 'success')

            # Redirect based on role
            if user.role == 'admin':
                return redirect(url_for('dashboard.admin_dashboard'))
            else:
                return redirect(url_for('dashboard.student_dashboard'))
        else:
            flash('Invalid username or password.', 'danger')

    return render_template('login.html')


# ─────────────────────────────────────────────
# REGISTER
# ─────────────────────────────────────────────
@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """Show registration form (GET) or create a new student account (POST)."""
    if 'user_id' in session:
        return redirect(url_for('dashboard.home'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()
        confirm = request.form.get('confirm_password', '').strip()

        # Basic validation
        if not username or not email or not password:
            flash('All fields are required.', 'warning')
            return render_template('register.html')

        if password != confirm:
            flash('Passwords do not match.', 'danger')
            return render_template('register.html')

        if len(password) < 6:
            flash('Password must be at least 6 characters.', 'warning')
            return render_template('register.html')

        # Check for existing username / email
        if User.query.filter_by(username=username).first():
            flash('Username already taken. Please choose another.', 'danger')
            return render_template('register.html')

        if User.query.filter_by(email=email).first():
            flash('Email already registered. Please log in.', 'danger')
            return render_template('register.html')

        # Create user
        new_user = User(username=username, email=email, role='student')
        new_user.set_password(password)
        db.session.add(new_user)
        db.session.flush()  # Get user.id before commit

        # Create empty student profile linked to user
        profile = StudentProfile(user_id=new_user.id, name=username)
        db.session.add(profile)
        db.session.commit()

        flash('Account created successfully! Please log in.', 'success')
        return redirect(url_for('auth.login'))

    return render_template('register.html')


# ─────────────────────────────────────────────
# LOGOUT
# ─────────────────────────────────────────────
@auth_bp.route('/logout')
def logout():
    """Clear session and redirect to login page."""
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))
