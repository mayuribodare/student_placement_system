# routes/company_routes.py
# Company management routes — list (all users), add/edit/delete (admin only)

from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from extensions import db
from models.company import Company

company_bp = Blueprint('company', __name__, url_prefix='/company')


def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to continue.', 'warning')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to continue.', 'warning')
            return redirect(url_for('auth.login'))
        if session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard.home'))
        return f(*args, **kwargs)
    return decorated


# ─────────────────────────────────────────────
# LIST COMPANIES
# ─────────────────────────────────────────────
@company_bp.route('/')
@login_required
def list_companies():
    """Show all companies to any logged-in user."""
    companies = Company.query.order_by(Company.name).all()
    return render_template('companies/list.html', companies=companies)


# ─────────────────────────────────────────────
# ADD COMPANY
# ─────────────────────────────────────────────
@company_bp.route('/add', methods=['GET', 'POST'])
@admin_required
def add_company():
    """Admin: Add a new company."""
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        if not name:
            flash('Company name is required.', 'warning')
            return render_template('companies/form.html', company=None)

        company = Company(
            name=name,
            industry=request.form.get('industry', '').strip(),
            location=request.form.get('location', '').strip(),
            email=request.form.get('email', '').strip(),
            website=request.form.get('website', '').strip()
        )
        db.session.add(company)
        db.session.commit()
        flash(f'Company "{name}" added successfully!', 'success')
        return redirect(url_for('company.list_companies'))

    return render_template('companies/form.html', company=None)


# ─────────────────────────────────────────────
# EDIT COMPANY
# ─────────────────────────────────────────────
@company_bp.route('/edit/<int:company_id>', methods=['GET', 'POST'])
@admin_required
def edit_company(company_id):
    """Admin: Edit an existing company."""
    company = Company.query.get_or_404(company_id)

    if request.method == 'POST':
        company.name = request.form.get('name', '').strip()
        company.industry = request.form.get('industry', '').strip()
        company.location = request.form.get('location', '').strip()
        company.email = request.form.get('email', '').strip()
        company.website = request.form.get('website', '').strip()
        db.session.commit()
        flash('Company updated successfully!', 'success')
        return redirect(url_for('company.list_companies'))

    return render_template('companies/form.html', company=company)


# ─────────────────────────────────────────────
# DELETE COMPANY
# ─────────────────────────────────────────────
@company_bp.route('/delete/<int:company_id>', methods=['POST'])
@admin_required
def delete_company(company_id):
    """Admin: Delete a company and its associated jobs."""
    company = Company.query.get_or_404(company_id)
    db.session.delete(company)
    db.session.commit()
    flash(f'Company "{company.name}" deleted.', 'info')
    return redirect(url_for('company.list_companies'))
